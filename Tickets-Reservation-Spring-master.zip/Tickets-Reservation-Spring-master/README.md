# Tickets Reservation web app in Spring
Maven Spring MVC Project with Spring Security, Hibernate as ORM, PostgreSQL as database, Bootstrap as view. <br/>
Change user role in UserServiceImpl.java to sign up user with admin rights.
