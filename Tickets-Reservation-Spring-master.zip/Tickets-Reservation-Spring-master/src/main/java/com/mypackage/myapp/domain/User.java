package com.mypackage.myapp.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) // strategia pola
	int id;

	@Column(name = "firstname", nullable = false) // nie moze byc nullem
	private String firstname;
	private String secondname;
	private String lastname;

	private String email;
	private String telephone;

	private String country;

	private String state;
	private String city;
	private String street;

	private String login;
	private String password;

	@ManyToMany(fetch = FetchType.EAGER)
	private Set<UserRole> userRole = new HashSet<UserRole>(0);

	@OneToMany(fetch = FetchType.EAGER)
	private Set<PlaneTicketOrder> planeTicketOrder = new HashSet<PlaneTicketOrder>(0);

	@OneToMany(fetch = FetchType.EAGER)
	private Set<TrainTicketOrder> trainTicketOrder = new HashSet<TrainTicketOrder>(0);
	
	
	
	public Set<TrainTicketOrder> getTrainTicketOrder() {
		return trainTicketOrder;
	}

	public void setTrainTicketOrder(Set<TrainTicketOrder> trainTicketOrder) {
		this.trainTicketOrder = trainTicketOrder;
	}

	public Set<PlaneTicketOrder> getPlaneTicketOrder() {
		return planeTicketOrder;
	}

	public void setPlaneTicketOrder(Set<PlaneTicketOrder> planeTicketOrder) {
		this.planeTicketOrder = planeTicketOrder;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<UserRole> getUserRole() {
		return userRole;
	}

	public void setUserRole(Set<UserRole> userRole) {
		this.userRole = userRole;
	}

	public String getFirstname() {
		return firstname;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getSecondname() {
		return secondname;
	}

	public void setSecondname(String secondname) {
		this.secondname = secondname;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

}
